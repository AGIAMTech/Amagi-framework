#!/usr/bin/env bash
# ================================================================
# AMAGI SCC v3 – verification run matrix (scc_amagi_v3.pml)
#
# Fixes the v2 packaging defect BUG-7: the v2 run_verify.sh used set -e,
# so a counterexample exit code (pan returns nonzero) could abort the
# remaining suite. Here there is NO set -e and every pan invocation is
# guarded with || true; each run appends to its own log with a "=== <claim>
# ===" header, so partial failure is visible but never masks later runs.
#
# Requirements: spin >= 6.5.2 (evidence chain was produced with
# 6.5.2 -- 6 December 2019), gcc, bash. Run from a working directory
# containing scc_amagi_v3.pml and fa1off_driver.pml.
#
# Tunables (environment variables):
#   W  – hash-table exponent, 2^W slots   (default 28, as in the v2 evidence)
#        NOTE: the SHIPPED evidence logs under verify/ were produced with
#        W=24 M=2000000 (CI-sized; see results_v3.md header). Verdicts and
#        state counts are identical either way.
#   M  – maximum search depth             (default 25000000, as in v2)
# Verdicts and state counts do not depend on W (lossless collapse
# compression); M must exceed the maximum DFS depth reached (v2 reached
# 5,729,493; v3 reaches 15,373 at most).
#
# Output: the three logs are written into the CURRENT working directory
# (default_safety_results.log, default_liveness_results.log,
# fa1off_liveness_results.log). The shipped evidence logs live under verify/
# and are deliberately NOT overwritten by a re-run.
#
# Usage: ./run_verify_v3.sh [model]
# ================================================================
set -u
MODEL="${1:-scc_amagi_v3.pml}"
W="${W:-28}"
M="${M:-25000000}"

SAFETY_CLAIMS="S01 S02 S03 S04 S05 S06 S07 S08 S09 FA1_INV"
LIVENESS_DEFAULT="FA2_RES L01 L02 L03 L04"
LIVENESS_FA1OFF="FA2_RES L01 L02 L03 L04"

say() { printf '%s\n' "$*"; }

build_default() {
  say "=== build default: spin -a $MODEL; gcc -DCOLLAPSE -O2 ==="
  spin -a "$MODEL" || return 1
  gcc -DCOLLAPSE -O2 -o pan pan.c || return 1
}

build_fa1off() {
  say "=== build FA1_OFF: spin -a fa1off_driver.pml; gcc -DCOLLAPSE -O2 ==="
  spin -a fa1off_driver.pml || return 1
  gcc -DCOLLAPSE -O2 -o pan_fa1off pan.c || return 1
}

# NOTE: must run AFTER build_default but BEFORE build_fa1off overwrites pan.c
run_default_safety() {
  : > default_safety_results.log
  for c in $SAFETY_CLAIMS; do
    say "=== $c ===" >> default_safety_results.log
    ./pan -N "$c" -w"$W" -m"$M" >> default_safety_results.log 2>&1 || true
  done
}

run_default_liveness() {
  : > default_liveness_results.log
  for c in $LIVENESS_DEFAULT; do
    say "=== $c (weak fairness, -a -f) ===" >> default_liveness_results.log
    ./pan -a -f -N "$c" -w"$W" -m"$M" >> default_liveness_results.log 2>&1 || true
  done
}

run_fa1off_liveness() {
  : > fa1off_liveness_results.log
  for c in $LIVENESS_FA1OFF; do
    say "=== $c (FA1_OFF, weak fairness, -a -f) ===" >> fa1off_liveness_results.log
    ./pan_fa1off -a -f -N "$c" -w"$W" -m"$M" >> fa1off_liveness_results.log 2>&1 || true
  done
}

say "AMAGI SCC v3 run matrix | model=$MODEL | W=$W M=$M | spin $(spin -V 2>/dev/null)"
build_default || { say "FATAL: default build failed"; exit 1; }
run_default_safety
run_default_liveness
build_fa1off || { say "FATAL: FA1_OFF build failed"; exit 1; }
run_fa1off_liveness
say "Suite complete: default_safety_results.log default_liveness_results.log fa1off_liveness_results.log"
