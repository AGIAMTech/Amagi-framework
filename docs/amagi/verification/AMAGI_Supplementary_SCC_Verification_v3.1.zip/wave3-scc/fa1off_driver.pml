/* FA1_OFF build driver for scc_amagi_v3.pml.
 * Removes the FA1 operational contract ([P9]) and restores the v2-style
 * unrestricted adversary on the emergency line. Purpose: demonstrate that
 * FA1 is a load-bearing assumption (L01/L02/L03 counterexamples reappear,
 * routed through the emergency path only), while L04 and FA2_RES remain
 * unconditional — the Open Problem 1 mechanism of v2 stays eliminated.
 * See the v3 header and results_v3.md for the honest status table. */
#define FA1_OFF
#include "scc_amagi_v3.pml"
