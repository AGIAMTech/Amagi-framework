/* ================================================================
 * AMAGI SCC – verification model v3
 * (15 LTL: 9 safety [8 non-vacuous + S09 vacuous, BUG-3],
 *  2 assumption-contract claims, 4 liveness)
 *
 * Changes from v2 (scc_amagi_v2.pml):
 *   [P7] DDL watchdog inside SCC_Core: deterministic counter ddl_cnt with
 *        hardware bound TWD. While in DELAYED_ALLOW, the forced timeout
 *        transition fires once ddl_cnt reaches TWD and no delay_elapsed is
 *        observed: atomic latch-clearing + SAFE_STATE. This encodes the
 *        hardware DDL-watchdog mechanism that v2 only promised in comments
 *        ("atomic latch-clearing on timeout").
 *   [P8] hw_emergency becomes an EXCLUSIVE guard: every normal branch is
 *        masked with !hw_emergency; when the line is asserted, the emergency
 *        transition is the only executable SCC_Core branch. This removes the
 *        branch-fairness hole of v2 (SPIN weak fairness is per-process, not
 *        per-branch: in v2 the scheduler could keep choosing DELAYED_ALLOW
 *        forever while hw_emergency=1 stayed pending — the L04 mechanism).
 *   [P9] FA1/FA2 are ENCODED in the model — closes TCAD-2026-1011 MC3
 *        ("FA1/FA2: Definition in article" placeholders):
 *        FA1 – operational contract on the emergency line (assumption):
 *              the line may be armed only while the core is at rest
 *              (state == IDLE), and every assertion is released within
 *              EMG_HOLD Environment cycles by a forced countdown.
 *              Verified consequence: invariant FA1_INV — hw_emergency == 0
 *              throughout the request lifecycle (assume-guarantee form).
 *        FA2 – hardware guarantee that a delay episode is bounded (theorem):
 *              encoded by [P7], verified as claim FA2_RES: every
 *              DELAYED_ALLOW episode resolves (state leaves DELAYED_ALLOW).
 *   [P10] run_verify_v3.sh guards every liveness invocation with || true
 *        (v2 run_verify.sh used set -e and could abort the suite on the
 *        first counterexample exit code — BUG-7).
 *   [P11] Dead-input pruning (BUG-4): the environment inputs mag_row /
 *        int_class / domain are unread in the abstract FSM — neither the
 *        transition guards nor any of the S/FA/L claims reference them —
 *        yet they multiplied the v2 state space by 16x4x2 = 128. v3 removes
 *        them together with their select() statements. The pruning is
 *        semantically neutral for every property in the suite and is
 *        required for feasibility: with the [P7]/[P9] counters present,
 *        the v2 bloat would push the exhaustive product search beyond
 *        3x10^8 states. The v2 evidence chain (25,927,680 states, "R2
 *        reproduction" class) remains attached to v2; v3 is verified and
 *        reported in its own right.
 *
 * Verification regimes:
 *   - default build:            FA1 encoded. Run matrix: S01–S09 and FA1_INV
 *                               as safety claims; FA2_RES and L01–L04 as
 *                               liveness claims (-a -f).
 *   - -DFA1_OFF build (wrapper fa1off_driver.pml): the FA1 contract is
 *                               removed and the adversary regains the v2
 *                               free emergency line. Observed (measured,
 *                               see results_v3.md and verify/ logs): L01/L02/
 *                               L03 produce counterexamples whose cycles go
 *                               through the emergency path only — showing
 *                               FA1 is a load-bearing assumption, not
 *                               decoration. L04 and FA2_RES still hold
 *                               unconditionally: the v2 counterexample
 *                               (Open Problem 1) no longer exists in v3.
 *
 * Honesty notes (carried from the v2/v3 defect ledger):
 *   - S09 is vacuously true in the PML abstraction: ERROR has no incoming
 *     transitions here (reachable only in concrete RTL). Kept verbatim from
 *     v2 for evidence continuity; marked vacuous in the results table.
 *   - S10_ARCH/S11_ARCH (INV-004/INV-006) remain architectural constants
 *     (#define ... false, i.e. []true) and are EXCLUDED from the v3 count
 *     of 15 LTL; v2 counted them in its 15.
 *   - mag_row/int_class/domain: REMOVED in v3 under [P11] together with
 *     their select() statements (unread by the abstract FSM, 128x state
 *     bloat, BUG-4). The pruning is semantically neutral for every claim
 *     in the suite. The v2 evidence chain (25,927,680 states = "R2
 *     reproduction" class) remains attached to v2 and is NOT directly
 *     comparable with v3 state counts; see results_v3.md §4 for the
 *     state-space accounting (decomposition of the ~402x).
 *
 * Traceability: TCAD-2026-1011 MC3, MC5; R1 Section 4 (bounded liveness,
 * assume-guarantee contracts); Open Problem 1.
 * ================================================================ */

#define IDLE            0
#define POLICY_EVAL     1
#define DELAYED_ALLOW   2
#define IMMEDIATE_ALLOW 3
#define DENY            4
#define SAFE_STATE      5
#define AUDIT_WRITE     6
#define EMERGENCY_CUTOFF 7
#define AUTH_WAIT       8
#define ERROR           9
#define RESET           10
#define POWER_UP        11

/* [P7]/[P9] Hardware constants of the verification model.
 * TWD      – DDL watchdog bound, in SCC_Core cycles (hardware reload value).
 *            A delay episode is bounded by TWD+1 core cycles.
 * EMG_HOLD – bound on one hw_emergency assertion, in Environment cycles (FA1).
 */
#define TWD       4
#define EMG_HOLD  2

/* Architectural assumption constants (INV-004, INV-006) — unchanged from v2.
 * Enforced by hardware construction, not by state-space exploration:
 * the corresponding LTL instantiations are trivially true ([](true)).
 */
#define policy_mutable      false
#define cognitive_read_audit false

/* --- Global variables --- */
byte state = IDLE;

bool policy_ok, delay_elapsed, delay_timeout, trigger, actuate;
bool latch_trigger, latch_policy, latch_delay;
bool hw_emergency;

byte ddl_cnt = 0;   /* [P7] DDL watchdog counter: 0 outside DELAYED_ALLOW */
byte emg_cnt = 0;   /* [P9] FA1 release countdown (Environment bookkeeping) */

byte audit_queue[16];
byte head = 0;

/* --- Macros (unchanged from v2) --- */
#define ttp_trigger  latch_trigger
#define ttp_policy   latch_policy
#define ttp_delay    latch_delay
#define audit_count  head
#define emergency    (state == EMERGENCY_CUTOFF)

/* ================================================================
 * Environment: nondeterministic adversary.
 * Selects all observable inputs. hw_emergency is gated by the FA1
 * contract [P9] unless compiled with -DFA1_OFF (v2-style unrestricted
 * adversary, used to demonstrate that FA1 is necessary).
 * [P11] The v2 interface variables mag_row/int_class/domain are removed
 * (unread in the abstract FSM; see BUG-4 in the header).
 * ================================================================ */
active proctype Environment() {
    do
    :: if :: policy_ok = true      :: policy_ok = false      fi;
       if :: delay_elapsed = true  :: delay_elapsed = false  fi;
       if :: delay_timeout = true  :: delay_timeout = false  fi;
       if :: trigger = true        :: trigger = false         fi;
#ifdef FA1_OFF
       /* v2 semantics: free emergency line (FA1 contract disabled). */
       if :: hw_emergency = true   :: hw_emergency = false    fi;
#else
       /* [P9] FA1 (operational contract, encoded):
        * - the emergency line may be armed only while the core is at
        *   rest (state == IDLE); the guard is RE-CHECKED inside the
        *   arming atomic, because a two-step check-then-arm without the
        *   re-check has a guard-lift race (an earlier draft of this
        *   encoding produced a genuine pan counterexample of exactly
        *   that shape: the line armed itself while the core was already
        *   in AUDIT_WRITE — see results_v3.md, FA1_INV iteration 1);
        * - while emg_cnt > 0 the forced countdown is the ONLY enabled
        *   emergency action (no skip alternative), so release is
        *   deterministic and every assertion is bounded;
        * - in the lifecycle (state != IDLE, line low) the emergency
        *   action is quiescent: the adversary keeps full freedom over
        *   all other inputs.
        * Verified consequence: invariant FA1_INV (hw_emergency == 0
        * during the whole request lifecycle). */
       if
       :: (emg_cnt > 0) ->
            atomic {
                emg_cnt--;
                if
                :: (emg_cnt == 0) -> hw_emergency = false;
                :: else -> skip;
                fi;
            }
       :: (emg_cnt == 0 && !hw_emergency) ->
            atomic {
                if
                :: (state == IDLE) -> hw_emergency = true; emg_cnt = EMG_HOLD;
                :: else -> skip;   /* FA1: re-checked at arming time */
                fi;
            }
       :: else -> skip;   /* FA1: quiescent during the request lifecycle */
       fi;
#endif
    od;
}

/* ================================================================
 * SCC Core FSM — v3
 * [P8] every normal branch is masked with !hw_emergency (exclusive
 *      guard); [P7] DDL watchdog in DELAYED_ALLOW.
 * ================================================================ */
active proctype SCC_Core() {
    do
    /* [P2/P8] Hardware emergency: exclusive guard. When hw_emergency is
     * asserted this is the ONLY executable branch (all normal branches
     * are masked), so the transition cannot be starved by the scheduler
     * (v2 branch-fairness hole). Clears actuate and all latches for a
     * clean recovery path: EMERGENCY_CUTOFF -> RESET -> IDLE.
     */
    :: hw_emergency ->
        atomic {
            actuate = false;
            latch_trigger = false;
            latch_policy = false;
            latch_delay = false;
            ddl_cnt = 0;
            state = EMERGENCY_CUTOFF;
        }

    /* IDLE: wait for trigger (masked [P8]).
     * The admission decision re-checks !hw_emergency inside the atomic:
     * the FA1 contract allows arming while the core is at rest, so the
     * line can rise between the outer guard and the atomic body; in that
     * case admission is withdrawn and the emergency branch takes over. */
    :: (state == IDLE) && !hw_emergency ->
        atomic {
            if
               :: !hw_emergency && trigger -> latch_trigger = true; state = POLICY_EVAL;
               :: else -> skip;
            fi;
        }

    /* POLICY_EVAL: latch policy decision (masked [P8]).
     * [P7] The watchdog is armed (reset to 0) on entering DELAYED_ALLOW. */
    :: (state == POLICY_EVAL) && !hw_emergency ->
        atomic {
            latch_policy = policy_ok;
            ddl_cnt = 0;
            if
               :: latch_policy -> state = DELAYED_ALLOW;
               :: else -> state = DENY;
            fi;
        }

    /* DELAYED_ALLOW: wait for delay line OR timeout [P1].
     * Priority order (documented, matches the RTL priority mux):
     *   1. delay_elapsed                  -> normal completion
     *   2. ddl_cnt >= TWD (no elapsed)    -> [P7] forced watchdog timeout:
     *      atomic latch-clearing + SAFE_STATE (FA2 hardware guarantee)
     *   3. delay_timeout (no elapsed)     -> env-signalled timeout; subsumed
     *      by 2 in v3, retained verbatim for interface compatibility with
     *      the v2 evidence chain
     *   4. else (ddl_cnt < TWD)           -> stay one cycle, watchdog tick
     */
    :: (state == DELAYED_ALLOW) && !hw_emergency ->
        atomic {
            if
               :: delay_elapsed ->
                   latch_delay = true;
                   ddl_cnt = 0;
                   state = IMMEDIATE_ALLOW;
               :: (ddl_cnt >= TWD) && !delay_elapsed ->      /* [P7] */
                   actuate = false;
                   latch_trigger = false;                    /* atomic latch-clearing */
                   latch_policy = false;
                   latch_delay = false;
                   ddl_cnt = 0;
                   state = SAFE_STATE;
               :: delay_timeout && !delay_elapsed ->
                   actuate = false;
                   ddl_cnt = 0;
                   state = SAFE_STATE;
               :: (ddl_cnt < TWD) ->
                   ddl_cnt++;
            fi;
        }

    /* IMMEDIATE_ALLOW: actuate (TTP satisfied) — masked [P8] */
    :: (state == IMMEDIATE_ALLOW) && !hw_emergency ->
        atomic { actuate = true; state = AUDIT_WRITE; }

    /* DENY: reject request — masked [P8] */
    :: (state == DENY) && !hw_emergency ->
        atomic { actuate = false; state = AUDIT_WRITE; }

    /* AUDIT_WRITE: record decision, reset latches, return to IDLE — masked [P8] */
    :: (state == AUDIT_WRITE) && !hw_emergency ->
        atomic {
            assert(head < 16);
            audit_queue[head] = 1;
            head = (head + 1) % 16;
            actuate = false;
            latch_trigger = false;
            latch_policy = false;
            latch_delay = false;
            state = IDLE;
        }

    /* SAFE_STATE: timeout recovery, clear latches, return to IDLE — masked [P8] */
    :: (state == SAFE_STATE) && !hw_emergency ->
        atomic {
            actuate = false;
            latch_trigger = false;
            latch_policy = false;
            latch_delay = false;
            state = IDLE;
        }

    /* EMERGENCY_CUTOFF -> RESET (masked [P8]; the emergency branch above
     * handles hw_emergency == 1, including the self-loop while the line
     * is held) */
    :: (state == EMERGENCY_CUTOFF) && !hw_emergency ->
        atomic { state = RESET; }

    /* Housekeeping states -> IDLE
     * NOTE (unchanged from v2): AUTH_WAIT, ERROR, POWER_UP have exit
     * transitions but no incoming transitions in the abstract PML model;
     * they are reachable only in the concrete RTL (hardware init, ECC
     * error detection, auth timeout). 9 of 12 defined states are reachable
     * in this PML abstraction — hence S09 is vacuously true here.
     */
    :: (state == AUTH_WAIT) && !hw_emergency ->
        atomic { state = IDLE; }

    :: ((state == ERROR || state == RESET || state == POWER_UP)) && !hw_emergency ->
        atomic { state = IDLE; }
    od;
}

/* ================================================================
 * 9 non-trivial safety properties — VERBATIM from v2
 * (evidence continuity with the R2-reproduced numbers)
 * ================================================================ */
ltl S01 { [] (actuate -> (ttp_trigger && ttp_policy && ttp_delay)) }
ltl S02 { [] (actuate -> latch_trigger) }
ltl S03 { [] (actuate -> ttp_policy) }
ltl S04 { [] (actuate -> ttp_delay) }
/* S05 (v2 renumbering preserved): actuation only from the allow path */
ltl S05 { [] (actuate -> (state == IMMEDIATE_ALLOW || state == AUDIT_WRITE)) }
ltl S06 { [] ((state == SAFE_STATE) -> !actuate) }
ltl S07 { [] ((state == DENY) -> !actuate) }
ltl S08 { [] ((state == EMERGENCY_CUTOFF) -> !actuate) }
ltl S09 { [] ((state == ERROR) -> !actuate) }   /* vacuous in PML (BUG-3) */

/* ================================================================
 * 2 architectural assumptions (NOT state-space verified) — unchanged
 * from v2: #define ... false -> [](true) trivially. EXCLUDED from the
 * v3 count of 15 LTL; documented for INV-004/INV-006 traceability.
 * ================================================================ */
/* ltl S10_ARCH { [] (!policy_mutable) }        — INV-004 (architectural) */
/* ltl S11_ARCH { [] (!cognitive_read_audit) }  — INV-006 (architectural) */

/* ================================================================
 * [P9] Assumption contracts as verified claims (closes MC3)
 * FA1_INV – the FA1 contract implies: no emergency during the request
 *           lifecycle (assume-guarantee invariant, safety claim).
 * FA2_RES – every delay episode resolves: the core cannot remain in
 *           DELAYED_ALLOW forever (liveness claim; the bound TWD+1 is
 *           enforced by the [P7] counter, not by the LTL formula).
 * ================================================================ */
ltl FA1_INV { [] ((state == POLICY_EVAL || state == DELAYED_ALLOW ||
                   state == IMMEDIATE_ALLOW || state == DENY ||
                   state == AUDIT_WRITE || state == SAFE_STATE) -> !hw_emergency) }
ltl FA2_RES { [] ((state == DELAYED_ALLOW) -> <> (state != DELAYED_ALLOW)) }

/* ================================================================
 * 4 liveness properties — VERBATIM from v2
 * v2 status: L01–L03 CE (branch-fairness hole, "analytically argued"
 * under FA1∧FA2); L04 UNCONDITIONAL CE = Open Problem 1.
 * v3 status: L01–L03 verified under the encoded FA1 contract (FA1_OFF
 * build reproduces obligation-breaking counterexamples through the
 * emergency path only, showing FA1 is necessary); L04 and FA2_RES hold
 * unconditionally — the watchdog (FA2) no longer depends on any
 * environment fairness, so Open Problem 1 is closed by construction.
 * ================================================================ */
ltl L01 { [] ((ttp_trigger && ttp_policy && ttp_delay && !emergency) -> <> actuate) }
ltl L02 { [] ((state == DENY) -> <> (audit_count > 0)) }
ltl L03 { [] ((state == SAFE_STATE) -> <> (state == IDLE)) }
ltl L04 { [] (latch_trigger -> <> (!latch_trigger)) }
