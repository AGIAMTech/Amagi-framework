# AMAGI SCC — Verification Model v3

**Status: Published — package v3.1** (Zenodo record 23797818, concept DOI
10.5281/zenodo.23797817, part of the AMAGI corpus). v3.1 is a
documentation/packaging fix release: the model's semantics, verdicts and state
counts are identical to the originally published v3 (comments and docs only —
see Version history at the end of this file).

## What this is

`scc_amagi_v3.pml` is the successor of the SCC verification model `scc_amagi_v2.pml`
(the artifact independently re-run by Reviewer 2 during TCAD-2026-1011). It closes
two open items of the review:

- **MC3** — FA1/FA2 were placeholders ("Definition in article"). In v3 both are
  encoded: FA1 as an operational contract on the emergency line (arming restricted
  to core-at-rest, bounded release, verified consequence `FA1_INV`); FA2 as the DDL
  watchdog ([P7]) with its resolution claim `FA2_RES`.
- **Open Problem 1** — v2's L04 had an unconditional counterexample. In v3 the
  watchdog bounds every delay episode (≤ TWD+1 core cycles) and the exclusive
  `hw_emergency` guard ([P8]) makes the emergency transition un-starvable;
  L04 verifies unconditionally, with and without FA1.

Full numbers, the FA1-necessity demonstration (FA1_OFF build), and the iteration-1
guard-lift catch: see `results_v3.md`. Line-by-line change record: `diff_v2_to_v3.patch`
(also summarized as [P7]–[P11] in the model header).

## File manifest

| File | Purpose |
|------|---------|
| `scc_amagi_v3.pml` | Verification model v3 (15 LTL claims) |
| `fa1off_driver.pml` | FA1_OFF build wrapper (FA1-necessity demonstration) |
| `run_verify_v3.sh` | Run matrix: builds both configurations, runs 20 pan invocations (15 unique claims; FA2_RES and L01–L04 are re-verified in the FA1_OFF build), BUG-7-safe |
| `results_v3.md` | Verdict tables, honest status ledger, iteration-1 record |
| `diff_v2_to_v3.patch` | Unified diff, v2 → v3 |
| `LICENSE` | CC BY-NC 4.0 notice |
| `verify/default_safety_results.log` | S01–S09 + FA1_INV, default build (raw pan output) |
| `verify/default_liveness_results.log` | FA2_RES + L01–L04, default build (-a -f) |
| `verify/fa1off_liveness_results.log` | L01–L04, FA1_OFF build (-a -f) |
| `verify/FA1_INV_iteration1_evidence.log` | The guard-lift counterexample found in the first encoding draft. The file contains the full iteration-1 run matrix (S01–S09 and FA1_INV): only FA1_INV fails — this is the point |
| `verify/trails/fa1off_L01.trail`, `fa1off_L02.trail`, `fa1off_L03.trail` | Counterexample trails (FA1_OFF) |

Checksums: `verify/checksums.txt` (SHA-256, computed after the manifest was
frozen). It covers every shipped file except `checksums.txt` itself
(self-reference is impossible).

## Reproduction

Requirements: Spin ≥ 6.5.2 (evidence chain produced with 6.5.2 -- 6 December 2019),
gcc, bash. From this directory:

```bash
W=24 M=2000000 ./run_verify_v3.sh       # CI-sized parameters — THE SHIPPED
                                        # verify/ LOGS WERE PRODUCED THIS WAY
W=28 M=25000000 ./run_verify_v3.sh      # v2-evidence-sized defaults of the script,
                                        # same verdicts
```

The script writes `default_safety_results.log`, `default_liveness_results.log`,
`fa1off_liveness_results.log` in the **current working directory** — NOT into
`verify/`. The files under `verify/` are the shipped evidence runs and are
deliberately not overwritten by a re-run. A fresh run need not reproduce them
byte-for-byte; the verdicts and state counts must match `results_v3.md`.
Runtime on 2 vCPU: under one minute at W=24.

Note on warnings: the `warning: never claim + accept labels requires -a flag`
line on the safety runs is benign — acceptance cycles are not selected for
safety claims (each log shows `acceptance cycles - (not selected)` for them).

Single-claim examples:

```bash
spin -a scc_amagi_v3.pml && gcc -DCOLLAPSE -O2 -o pan pan.c
./pan -N S01 -w24 -m2000000                 # safety
./pan -a -f -N L04 -w24 -m2000000           # liveness (Open Problem 1 check)
spin -a fa1off_driver.pml && gcc -DCOLLAPSE -O2 -o pan_fa1off pan.c
./pan_fa1off -a -f -N L04 -w24 -m2000000    # still no acceptance cycle without FA1
```

## Packaging checklist (defect ledger BUG-2/BUG-6, resolved here)

- [x] README manifest names exactly the files that ship (v2 promised 7, shipped 4)
- [x] LICENSE included (v2 shipped none)
- [x] No personal information in paths or logs (v2 WSL paths contained PII)
- [x] Verification logs ship with the model (v2 omitted `spin_results.log`)
- [x] Checksums for every file
- [x] Same Spin version as the published evidence chain (6.5.2)

## Traceability

TCAD-2026-1011: MC3 (assumptions not encoded — closed by [P9]/FA1_INV/FA2_RES),
MC5 (weak property suite — partially addressed here; the RTL-level suite is a
separate artifact), R1 Section 4 (bounded liveness, assume-guarantee contracts),
Open Problem 1 (closed by [P7]/[P8]). Companion documents: Master Parameter Sheet
v2.1, Verification Casebook v1.1 §6 evidence classes.

## License

CC BY-NC 4.0. Copyright 2026 AGIAM Technologies Ltd (In Formation) / Alexey M. Burlai.

## Version history

- **v3.0** — initial published package (Zenodo record 23797818).
- **v3.1** — packaging/documentation fixes only; model semantics, verdicts and
  state counts unchanged:
  - stale honesty note in the model header aligned with [P11] (the dead inputs
    ARE removed in v3, together with their `select()` statements; pruning is NOT
    deferred);
  - `diff_v2_to_v3.patch` regenerated against the shipped model (the v3.0 patch
    was frozen one comment-edit earlier than the model);
  - "19 checks" corrected to 20 pan invocations (15 unique claims);
  - log-path, run parameters of the shipped evidence, checksums coverage and the
    benign `-a` warning documented;
  - FA1_INV scope (lifecycle states only), latch-clearing asymmetry, `emg_cnt`
    placement, S09 vacuity split in the headline and the decomposition of the
    ~402× state-space reduction (residual ≈3.1× measured against the
    iteration-1 evidence) added to `results_v3.md`;
  - copyright line aligned with the AMAGI corpus ("Ltd (In Formation)").
