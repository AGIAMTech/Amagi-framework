# AMAGI SCC — Verification Model v3 — Results

**Model:** `scc_amagi_v3.pml` (15 LTL claims: 9 safety — 8 non-vacuous + S09 vacuous (BUG-3, evidence continuity) — 2 assumption-contract, 4 liveness)
**Baseline:** `scc_amagi_v2.pml` (13 LTL; 25,927,680 states, independently reproduced by Reviewer 2)
**Toolchain:** Spin 6.5.2 (6 December 2019) — the same version as the owner's evidence
chain and the R2 reproduction; gcc 14.2.0 (Debian); compile `gcc -DCOLLAPSE -O2`;
runtime `-w24 -m2000000` (RAM-constrained CI host; verdicts and state counts are
invariant to the hash-table size `-w`, lossless collapse compression; `-m` must exceed
the maximum DFS depth, which is 15,373 here — the v2 evidence used `-w28 -m25000000`).
**Run script:** `run_verify_v3.sh` (BUG-7 fixed: no `set -e`; every pan invocation
guarded with `|| true`).

---

## 1. Verdict table — default build (FA1 encoded)

| Claim | Class | Verdict | States, stored | Transitions | Depth | Errors |
|-------|-------|---------|---------------:|------------:|------:|-------:|
| S01 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S02 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S03 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S04 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S05 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S06 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S07 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S08 | safety | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| S09 | safety | **vacuously true** (ERROR unreachable in the PML abstraction, BUG-3) | 64,512 | 177,025 | 14,361 | 0 |
| FA1_INV | assumption contract (safety) | **verified** | 64,512 | 177,025 | 14,361 | 0 |
| FA2_RES | assumption contract (liveness) | **verified** | 81,792 | 486,785 | 14,361 | 0 |
| L01 | liveness (-a -f) | **verified** | 69,120 | 211,329 | 14,361 | 0 |
| L02 | liveness (-a -f) | **verified** | 64,992 | 182,433 | 14,361 | 0 |
| L03 | liveness (-a -f) | **verified** | 72,192 | 245,633 | 14,361 | 0 |
| L04 | liveness (-a -f) | **verified — unconditional** | 100,608 | 813,697 | 14,361 | 0 |

All searches completed (no `Search not completed` warnings). S10_ARCH/S11_ARCH
(INV-004/INV-006) remain documented architectural constants and are excluded from
the v3 count of 15.

**Headline: L04 — the unconditional counterexample of v2 ("Open Problem 1") — no
longer exists.** The v2 counterexample required the environment to keep the core
in DELAYED_ALLOW forever while hw_emergency=1 stayed pending (branch-fairness
hole); in v3 the [P7] watchdog bounds every delay episode (≤ TWD+1 core cycles)
and the [P8] exclusive guard makes the emergency transition un-starvable.

Scope notes (stated explicitly so they cannot be read as oversights):

- **FA1_INV quantifies over the request lifecycle states only** (POLICY_EVAL,
  DELAYED_ALLOW, IMMEDIATE_ALLOW, DENY, AUDIT_WRITE, SAFE_STATE). IDLE,
  EMERGENCY_CUTOFF and RESET are intentionally excluded: the line may lawfully
  be asserted while the core is at rest (FA1 permits arming in IDLE) and while
  the emergency path itself is executing.
- **Latch-clearing asymmetry (v2 verbatim, documented in the SCC_Core comment):**
  the [P7] watchdog clears all three latches atomically; the legacy
  env-signalled `delay_timeout` branch clears only `actuate` and is retained
  verbatim for interface compatibility with the v2 evidence chain. In v3 it is
  subsumed by the watchdog (priority order 1–4 in the DELAYED_ALLOW comment).

## 2. FA1 necessity demonstration — FA1_OFF build

The FA1_OFF build (`fa1off_driver.pml`) removes the encoded FA1 contract and
restores the v2-style unrestricted adversary on the emergency line.

| Claim | Verdict | Mechanism (from trail replay) | States | Depth |
|-------|---------|-------------------------------|-------:|------:|
| L01 | acceptance cycle (depth 41) | request latched, then emergency preempts via the exclusive branch; latches cleared; emergency self-loop holds actuate low forever | 668 | 856 |
| L02 | acceptance cycle (depth 4,660) | DENY entered, audit obligation broken by the emergency path; head stays 0 | 2,729 | 5,123 |
| L03 | acceptance cycle (depth 3,613) | SAFE_STATE left via emergency cutoff; IDLE never reached while the line is held | 2,304 | 4,054 |
| L04 | **verified — no cycle even without FA1** | the watchdog closes the delay episode; the exclusive guard forces latch clearance | 206,080 | 15,373 |
| FA2_RES | **verified — no cycle even without FA1** | every delay episode resolves; in FA1_OFF exits include the emergency cutoff | 159,360 | 15,373 |

Trails: `verify/trails/fa1off_L01.trail`, `fa1off_L02.trail`, `fa1off_L03.trail`.
Replay: `./pan_fa1off -r -N L01 -k verify/trails/fa1off_L01.trail` (or regenerate
with `./pan_fa1off -a -f -N L01`).

This is the honest reading of the v2 sentence "L01–L03 CE … (analytically argued)":
under the encoded FA1 the properties are machine-checked, without it they fail
exactly through the emergency path — FA1 is a load-bearing operational assumption,
and the model says so explicitly.

## 3. Verification log of the FA1 encoding itself (iteration 1)

The first draft of the [P9] encoding had a **guard-lift race**: the arm guard
`(emg_cnt == 0 && !hw_emergency && state == IDLE)` and the assignment
`hw_emergency = true` were separate Promela statements, so the core could leave
IDLE between them; the trail shows the line rising while the core was already in
AUDIT_WRITE (step 11,753). FA1_INV was violated at depth 11,753/11,754
(6,568 states) — evidence preserved verbatim in
`verify/FA1_INV_iteration1_evidence.log`. The file contains the full
iteration-1 run matrix (S01–S09 and FA1_INV): only FA1_INV fails there —
this is the point.

Fix (iteration 2, current model): arming is one atomic step with the `state == IDLE`
check re-evaluated inside it, and the IDLE admission re-checks `!hw_emergency`
inside its atomic body (the line may lawfully rise while the core is at rest; in
that case admission is withdrawn and the emergency branch takes over). After the
fix FA1_INV verifies with errors: 0.

The lesson is recorded deliberately: the assumption-encoding defect was not caught
by reading — it was caught by the model checker. This is part of the MC3 response
narrative: assumptions must be *encoded and verified as claims*, not cited.

## 4. State-space accounting (honest numbers)

| Model | Safety states | Notes |
|-------|--------------:|-------|
| v2 | 25,927,680 | includes 128× bloat from unread inputs mag_row/int_class/domain (BUG-4) |
| v3 | 64,512 | dead inputs pruned [P11]; watchdog [P7] and FA1 bookkeeping [P9] added |

Decomposition of the ~402× (25,927,680 / 64,512): the 128× dead-input pruning
accounts for 25,927,680 → 202,560. The residual ≈3.1× is measured, not assumed:
the iteration-1 draft (racy FA1 arming, before the fix of §3) already ran with
the pruned inputs (state-vector 52 bytes in the iteration-1 log, same as v3 —
mag_row/int_class/domain were already gone) and measured 238,464 safety states;
after the arming fix the same suite measures 64,512 (238,464 / 64,512 ≈ 3.7×).
See `verify/FA1_INV_iteration1_evidence.log`.

Net verification cost reduced ~402× while the claim suite grows from 13 to 15.
The v2 number keeps its evidence class ("R2 reproduction") attached to v2; v3 is
reported in its own right and is reproducible from the package in minutes.

## 5. Remaining honesty ledger for this artifact

- S09 vacuous in the PML abstraction (BUG-3) — kept verbatim, marked above.
- `assert(head < 16)` and the audit queue remain decorative in the abstract model
  (BUG-5/BUG-6); audit depth is NOT part of this artifact's claim suite — it is
  covered by the RTL-level suite (MC5). The abstract model keeps the v2 verbatim
  statements so the v2→v3 diff remains a reviewable record of exactly what changed.
- `emg_cnt` bookkeeping lives in `Environment` by design: FA1 is an operational
  assumption on the *external* emergency line, so its encoding (the forced
  countdown) is Environment-side modelling of that external contract. The
  hardware mechanism is FA2 — the [P7] watchdog inside SCC_Core — verified as
  FA2_RES. FA1_INV verifies the assumption; FA2_RES verifies the mechanism.
- mag_row/int_class/domain carry no semantics in the abstract FSM; they are
  environment-facing interface variables in the RTL (BUG-4), pruned here under [P11].
